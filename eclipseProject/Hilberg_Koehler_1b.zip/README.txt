Run TCP Server
==============
- 'unzip Hilberg_Koehler_1b.zip' to unzip into local directory
- 'mkdir bin' in local directoy
- execute './terminalBuild.sh' to compile from terminal in local directory
- execute './terminalRunServer.sh' to run Server from terminal in local directory

Run UDP Client
==============
- execute './terminalRunClient.sh' to run Client from terminal in local directory with default parameters
or 'cd bin && java praktikum.sensors.Sensor -ip <server-ip> -i <interval> -r <threads>'

Run TCP Client
==============
- start Webbrowser (e.g. Firefox)
- go to address: http://<Server-IP>:9999


