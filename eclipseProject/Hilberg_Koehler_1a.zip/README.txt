Run TCP Server
==============
- 'unzip Hilberg_Koehler_1a.zip' to unzip into local directory
- 'mkdir bin' in local directoy
- execute './terminalBuild.sh' to compile from terminal in local directory
- execute './terminalRun.sh' to run from terminal in local directory

Run TCP Client
==============
- start Webbrowser (e.g. Firefox)
- go to address: http://<Server-IP>:9999
